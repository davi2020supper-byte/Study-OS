# Study OS PWA

Protótipo inicial mobile-first. Inclui dashboard, tarefas editáveis, conclusão de tarefas, progresso diário, armazenamento local e arquivos básicos de PWA.

## Publicar pelo celular
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta para a raiz.
2. Abra Settings > Pages.
3. Em Build and deployment, escolha Deploy from a branch, branch `main`, pasta `/root` e salve.
4. Abra o endereço HTTPS publicado no Chrome Android.
5. Menu ⋮ > Instalar aplicativo ou Adicionar à tela inicial.

## Limitações
Abas de cronograma, questões e perfil ainda serão implementadas. Indicadores de sessões e questões ainda são demonstrativos. Os dados ficam no armazenamento local do navegador; não há conta nem sincronização na nuvem.
